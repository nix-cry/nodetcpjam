const net = require('net');
const client = new net.Socket();
const port = 7073;
const host = '127.0.0.1';
//'192.168.0.125';

const fs = require('fs');
let xmlParser = require('xml2json');
const xml2js = require('xml2js');

client.connect(port, host, function() {
    console.log('Connected');
  //say();
    setInterval(() => 

    client.write(say()) 
    
    , 1000)
  //  

});


    function say(){
console.log("Dsd");
var obj = fs.readFileSync( 'xml.xml', 'utf8');
console.log(obj);
return obj;
}


