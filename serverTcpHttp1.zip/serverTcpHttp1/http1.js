const path  = require("path");
var fs = require('fs');
var app =require('express') (); 
var http =require('http').Server(app);
//var io =require('socket.io')(http, {
//  cors: {
//    origin: "*",
//  }
//});
const exec  = require("child_process");
const bodyParser = require('body-parser');
const express = require('express');
const multer  = require("multer");

var upload_f = multer({dest:"publish"});
app.use('/publish/', express.static('publish'));
const urlencodedParser = bodyParser.urlencoded({extended: false});
app.set('view engine', 'ejs');
app.use(express.static(__dirname));

app.set('view engine', 'ejs');
app.get('/',(req,res) => {
	res.sendfile(__dirname + '/main.html');
    //res.sendFile("publish/main.html");
    //res.render('rpHtml');
});

app.get('/setting',(req,res) => {
	res.sendfile(__dirname + '/setting.html');
    //res.sendFile("publish/main.html");
    //res.render('rpHtml');
});


// app.set('view engine', 'ejs');
// app.get('/',(req,res) => {
//     res.sendfile('index.html');
//     // res.render('rpHtml');
// });

app.post("/xml/", urlencodedParser, upload_f.any(), (req, res) => {
    let filedata = req.files;
//     var str_nme = req.body.name;
//     var str_msg = req.body.msg;
//     var str_time = req.body.timestr;
//     console.log('����������� ������������ �������� � ����');
  console.log(filedata);
 fs.unlink('publish/620b29ecb49ea5e33ddf69951dd1a95f', (err) => {
  if (err) throw err;

  console.log('Deleted');
});


  
  
//   console.log(filedata)
//     let dist = [];
//     for(let i = 0; i < filedata.length; i++){
//         var img = filedata[i].mimetype;  
//         var arr = img.split('/');
//         dist[i] = { "path" : "/publish/"+filedata[i].filename+"."+arr[1], "origname" : filedata[i].originalname, "type" : arr[0] };         
//         fs.rename('publish/'+filedata[i].filename, 'publish/'+filedata[i].filename+'.'+arr[1], function(err) {
//             if ( err ) console.log('ERROR: ' + err);
//         }); 
//     }
  });

app.post("/setting1/", urlencodedParser, upload_f.any(), (req, res) => {
    //let filedata = req.files;
    	var set1String = req.body.set1String;
	var set1Time1 = req.body.set1Time1;
	var set1Time2 = req.body.set1Time2;
	var set1color1 = req.body.set1color1;
	var set1color2 = req.body.set1color2;
	var set1Header = req.body.set1Header;
	var set1Text = req.body.set1Text;
	
	console.log(req.body.set1color1+' '+set1color2);
        
	var massJ = [
		{'set1String':set1String},
		{'set1Time1':set1Time1},
		{'set1Time2':set1Time2},
		{'set1color1':set1color1},
		{'set1color2':set1color2},
		{'set1Header':set1Header},
		{'set1Text':set1Text}
	];
	console.log(massJ);
	var str = JSON.stringify(massJ);
	fs.writeFileSync('setting1.json', str);
	
});


app.post("/setting2/", urlencodedParser, upload_f.any(), (req, res) => {
    //let filedata = req.files;
    	var set2TextPos = req.body.set2TextPos;
	var set2TextPx = req.body.set2TextPx;
	var set2color = req.body.set2color;
	var string1 = req.body.string1;
	var string2 = req.body.string2;
	var string3 = req.body.string3;
	var string4 = req.body.string4;
	var set2Time1 = req.body.set2Time1;

        

	var massJ = [
		{'string1':string1},
		{'string2':string2},
		{'string3':string1},
		{'string4':string2},
		{'set2Time1':set2Time1},
		{'string5':''}
	];
	console.log(massJ);
	var str = JSON.stringify(massJ);
	fs.writeFileSync('setting2.json', str);
	
//     var str_time = req.body.timestr;
//     console.log('����������� ������������ �������� � ����');
//  console.log(filedata);
// fs.unlink('publish/620b29ecb49ea5e33ddf69951dd1a95f', (err) => {
//  if (err) throw err;

//  console.log('Deleted');
});


app.post("/settingHtml/", urlencodedParser, upload_f.any(), (req, res) => {
    //let filedata = req.files;
    	var settingHtml = req.body.settingHtml;


        

	var massJ = [
		{'Html':settingHtml},

	];
	console.log(massJ);
	var str = JSON.stringify(massJ);

	fs.writeFileSync('settingopenhtml.json', str);
	
//     var str_time = req.body.timestr;
//     console.log('����������� ������������ �������� � ����');
//  console.log(filedata);
// fs.unlink('publish/620b29ecb49ea5e33ddf69951dd1a95f', (err) => {
//  if (err) throw err;

//  console.log('Deleted');

});



app.post("/restart/", urlencodedParser, upload_f.any(), (req, res) => {
	var restart = req.body.restart;

	exec("pm2 restart tcp.js", (error, stdout, stderr) => {

	});

	var massJ = [
		{'Html':'1'},
	];
	console.log(massJ);
	var str = JSON.stringify(massJ);

	fs.writeFileSync('settingopenhtml.json', str);

});


http.listen(3001, function( ) { 
    console.log('������� �� *:3001');
  });
