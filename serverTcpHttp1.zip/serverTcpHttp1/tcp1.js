var app =require('express') (); 
//var siofu = require("socketio-file-upload");
var http =require('http').Server(app);
var io =require('socket.io')(http, {
  cors: {
    origin: "*",
  }
});
const bodyParser = require('body-parser');
const express = require('express');
const multer  = require("multer");
//const app = express();
var upload_f = multer({dest:"publish"});
app.use('/publish/', express.static('publish'));
var net = require('net');
const fs = require('fs');
let xmlParser = require('xml2json');
const xml2js = require('xml2js');


var netServer = net.createServer(function(c) {
  console.log('client connected');

  var str = '';
  
 var strWeightSign = '';
 
 var strSign = '';

  
  var strPull = '';

  c.on('data', function(data) {

    
    if(data.toString().split('<?xml version="1.0" encoding="UTF-8"?>').length > 1 && data.toString().split('</Record>').length > 1){
      //console.log("Full");
      console.log('Received: ' + data);
      xml2js.parseString(data.toString(), function (err, result) {
        console.log(result.Record.VehicleInfo[0]["TrackStateNumber"][0]); // Output: Hello world!
      var obj = JSON.parse(fs.readFileSync( 'setting2.json', 'utf8'));

	  var objError = JSON.parse(fs.readFileSync( 'setting3.json', 'utf8'));
		
    		console.log(obj);
    		WeightSign = result.Record.TrackBaseMeasurements[0]["WeightSign"];
    		ThrustSign = result.Record.TrackBaseMeasurements[0]["ThrustSign"];
    		
    		LengthSign = result.Record.LengthMeasurements[0]["LengthSign"];
    		WidthSign = result.Record.WidthMeasurements[0]["WidthSign"];
    		HeightSign = result.Record.HeightMeasurements[0]["HeightSign"];

			PlatformId = result.Record.VehicleInfo[0]["PlatformId"];

			if(PlatformId==1){
    			if(WeightSign=='true' || ThrustSign=='true' || LengthSign=='true' || WidthSign=='true' || HeightSign=='true' ) {
    				if(WeightSign=='true'){
    					strWeightSign = objError[0].string1;
    				}else{strWeightSign='';}
    				if(ThrustSign=='true' || LengthSign=='true' || WidthSign=='true' || HeightSign=='true' ){
    				 	strSign = objError[1].string2;
    				}else{strSign='';}
				
				
    			    	strPull = strWeightSign + ' ' + strSign + ' ';
				
				
				
    				console.log("fff"+strPull);
    				var massJ1 = [
					{'string1':obj[0].string1},
					{'string2':obj[1].string2},
					{'string1':obj[2].string3},
					{'string2':obj[3].string4},
					{'set2Time1':obj[4].set2Time1},	
					{'string5':obj[0].string1+strPull+obj[1].string2+''+obj[2].string3+result.Record.VehicleInfo[0]["TrackStateNumber"][0]+obj[3].string4},
						];
					var str1 = JSON.stringify(massJ1);
					fs.writeFileSync('setting2.json', str1);
 					setTimeout(sayHi, 45000);
 					var massJ = [
						{'Html':'0'},

						];
					
					var str = JSON.stringify(massJ);
					fs.writeFileSync('settingopenhtml.json', str);
				}
			}	
      });
      data = '';
    }else{

      str += data;
      if(str.toString().split('<?xml version="1.0" encoding="UTF-8"?>').length > 1 && str.toString().split('</Record>').length > 1){
  
        xml2js.parseString(str.toString(), function (err, result) {
          //console.log(result.Record.VehicleInfo[0]["TrackStateNumber"]); // Output: Hello world!
          
          var obj = JSON.parse(fs.readFileSync( 'setting2.json', 'utf8'));

		  var objError = JSON.parse(fs.readFileSync( 'setting3.json', 'utf8'));
    		
    		WeightSign = result.Record.TrackBaseMeasurements[0]["WeightSign"];
    		ThrustSign = result.Record.TrackBaseMeasurements[0]["ThrustSign"];
    		
    		LengthSign = result.Record.LengthMeasurements[0]["LengthSign"];
    		WidthSign = result.Record.WidthMeasurements[0]["WidthSign"];
    		HeightSign = result.Record.HeightMeasurements[0]["HeightSign"];

    		if(WeightSign=='true' || ThrustSign=='true' || LengthSign=='true' || WidthSign=='true' || HeightSign=='true' ){
    			if(WeightSign=='true'){
    			 	strWeightSign = objError[0].string1;
    			}else{strWeightSign='';}
    			if(ThrustSign=='true' || LengthSign=='true' || WidthSign=='true' || HeightSign=='true' ){
    			 	strSign = objError[1].string2;
    			}else{strSign='';}
    		
    		
    		    	strPull = strWeightSign + ' ' + strSign + ' ';
    		
    			var massJ1 = [
				{'string1':obj[0].string1},
				{'string2':obj[1].string2},
				{'set2Time1':obj[2].set2Time1},	{'string3':obj[0].string1+strPull+obj[1].string2+'<br>'+obj[0].string1+result.Record.VehicleInfo[0]["TrackStateNumber"][0]+obj[1].string2},
					];
			var str1 = JSON.stringify(massJ1);
			fs.writeFileSync('setting2.json', str1);
 			setTimeout(sayHi, obj[2].set2Time1);
 			var massJ = [
						{'Html':'0'},

					];
				
			var str = JSON.stringify(massJ);
			fs.writeFileSync('settingopenhtml.json', str);
	}
				
        });
        str = '';
        data = '';
      }else if(str.toString().split('<?xml version="1.0" encoding="UTF-8"?>').length > 3 && str.toString().split('</Record>').length > 3){
        str = '';
        data = '';
      }
    }


    



});

    c.on('error', function(data) {
        //console.log("Caught flash policy server socket error: ");
    	//console.log(data);
    });


  c.on('end', function() {
    //console.log('client disconnected');
  });

  c.write('connect\r\n');
  c.pipe(c);
});


 	function sayHi() {
      					var massJ = [
						{'Html':'1'},

					];
				var str = JSON.stringify(massJ);
				fs.writeFileSync('settingopenhtml.json', str);
}


netServer.listen(7071);




















