//var http = require("http");
//let message = "Hello World!";
//const fs = require("fs");
////const ind = require("./index/in.js");








// var db;
// var dbY;
// var mes;
// connection.connect(function(err){
//     if (err) {
//         console.log("Ошибка: " + err.message);
//     }
//     else{
//         console.log("Подключение к серверу MySQL успешно установлено");
//       //console.log(db);
//     }
//  });




//  const user = [18, "rtt5465", "rtt", "rtrt"];
// const sql = "INSERT INTO primer(id, pr_name, pr_name2, pr_name3) VALUES(?, ?, ?, ?)";
 
// connection.query(sql, user, function(err, results) {
//     if(err) console.log(err);
//     else console.log("Данные добавлены");
// });


// //connection.execute("SELECT * FROM primer",
//  connection.query("SELECT * FROM primer",
//   function(err, results, fields) {
//     //console.log(err);
//     console.log(results); // собственно данные
//     //console.log(fields); // мета-данные полей 
// });

//  connection.end();
 //connection.destroy();
//  connection.end(function(err) {
//     if (err) {
//         console.log("Ошибка: " + err.message);
//     }
//     console.log("Подключение к серверу MySQL успешно установлено");
//   });


const mysql = require("mysql2");
const express = require("express");
const bodyParser = require("body-parser");
const multer  = require("multer");
const path  = require("path");
const cookieParser = require("cookie-parser");


const app = express();

const session = require('express-session');

app.use(bodyParser.json());

//const hbs = require('express-handlebars');

const urlencodedParser = bodyParser.urlencoded({extended: false});

const pool = mysql.createPool({
      connectionLimit: 5,
    host: "90.189.149.126",
    user: "node",
    password: "t8hoYFkD6TAO9V0v",
    database: "node",
    
    
});

//app.get("/", function(request, response){
//http.createServer(function(request, response){
    //let url = 'Запрошенный адрес:' + request.url;
    // console.log("Url: " + request.url);
    // console.log("Тип запроса: " + request.method);
    // console.log("User-Agent: " + request.headers["user-agent"]);
    // console.log("Все заголовки");
    // console.log(request.headers);
    // const filePath = ind.getPath()+request.url.substr(1);     
    // fs.access(filePath, fs.constants.R_OK, err => {
    //     // если произошла ошибка - отправляем статусный код 404
    //     if(err){
    //         response.statusCode = 404;
    //         response.end("Resourse not found!"+ind.getPath());
    //     }
    //     else{
            
    //         fs.createReadStream(filePath).pipe(response);
    //     }
    //   });
 //   response.send("<h2>Привет Express!</h2>");
//});
//app.engine('handlebars', handlebars({defaultLayout: 'main'}));
//app.set('views', './views');
app.set("view engine", "hbs");
//var sessionBd = require("./js/session_bd");

//var store = sessionBd.createStore();

app.use(cookieParser());
//app.use();
// app.post("/register", urlencodedParser, function (request, response) {
//     if(!request.body) return response.sendStatus(400);
//     console.log(request.body);
//     response.send(`${request.body.userName} - ${request.body.userAge}`);
// });

//app.post("/register", urlencodedParser, function (request, response) {
  //app.use(session({
  //  secret: 'you secret key',
 //   saveUninitialized: true
 //  }));

 //app.use(express.session());

 app.use(session({
   store: store,
  secret: 'aaa2C44-4D44-WppQ38Siuyiuy',
  resave: true,
  saveUninitialized: true
}));

let checkSignIn = (req, res, next) => {
  if (req.session.user) {   // после истичения сессии req.session.user всегда undefined, 
                                     //несмотря на то что в 
                                     //логине я повторно задаю это
                                   // свойство req.session.user = user['_id']
      next();
  } else {
      res.redirect("/in");
  }
}

app.get("/ind", checkSignIn, (req, res) => {

  //   // res.render("index.hbs", {
  //   //   session: req.session.showAd,
  //   //   title: "111",
  //   //     //users: data,
  //   // });
  //   var a = 'Sss';
  //   if(a == "Sss" ){
  // //app.get("/in", function(req, res){
  
  //   // session({
  //   //   secret: 'you secret key',
  //   //   saveUninitialized: true
  //   //  });
  //   // //req.session.showAd =  "Hello Session";
  //   // req.session.showAd =  "Helo session";
    
  //   req.session.showAd = "ASdadsds";
      pool.query("SELECT * FROM primer", function(err, data) {
  
        if(err) return console.log(err);
        
        res.render("index.hbs", {
          session: req.session.showAd,
          title: "111",
            users: data,
        });
  
      });
  
  });


//  app.post("/in",  (req, res) => {

//   if(req.body.usr == user && req.body.pwd == password)
//            req.session.user = user['_id']
//            res.redirect("/manage");
//         } else {
//           res.render("in.hbs", {
//             session: req.session.showAd,
//             title: "111",
          
//           });
//         }



// });

// }
// else{
//     res.render("in.hbs", {
//     session: req.session.showAd,
//     title: "111",
//       //users: data,
//   });

//   req.session.showAd == "ASdadsds";

// }
// });

app.get("/api", function(req, res){
  pool.query("SELECT * FROM primer", function(err, data) {
    if(err) return console.log(err);

    res.json({
      elements: data
  });

  });
});

//});


app.get("/create", function(req, res){
    res.render("create.hbs");
});

 app.use(express.static(__dirname));
    app.use(multer({dest:"publish"}).single("filedata"));


app.post("/create", urlencodedParser, function (req, res, next) {
         
    if(!req.body) return res.sendStatus(400);
    const name = req.body.name;
    const age = req.body.age;
    const fl = req.body.filedata;

   
    let filedata = req.file;
    console.log(filedata);
    if(!filedata){
        console.log("Ошибка при загрузке файла");
    }else{
        console.log("Файл загружен");
       // console.log(filedata);
    }


    pool.query("INSERT INTO primer (id, pr_name, pr_name2, pr_name3 ) VALUES (?,?,?,?)", [name,"/publish/"+filedata.filename,name, age], function(err, data) {
      if(err) return console.log(err);

     
      res.redirect("/in");
      
    });
});

app.get("/edit/:id", function(req, res){
    const id = req.params.id;
    pool.query("SELECT * FROM primer WHERE id=?", [id], function(err, data) {
      if(err) return console.log(err);
       res.render("edit.hbs", {
          user: data[0]
      });
    });
  });

  app.post("/edit", urlencodedParser, function (req, res) {
         
    if(!req.body) return res.sendStatus(400);
    const name = req.body.name;
    const age = req.body.age;
    const fl = req.body.filedata;

    let filedata = req.file;
    console.log(filedata);
    if(!filedata){
        console.log("Ошибка при загрузке файла");
    }else{
        console.log("Файл загружен");
       // console.log(filedata);
    }

    pool.query("UPDATE users SET pr_name=?, pr_name2=? WHERE id=?", ["/publish/"+filedata.filename,name, age, name], function(err, data) {
      if(err) return console.log(err);
       
      res.redirect("/");
    });
  });

app.post("/delete/:id", function(req, res){
          
    const id = req.params.id;
    pool.query("DELETE FROM primer WHERE id=?", [id], function(err, data) {
      if(err) return console.log(err);
      res.redirect("/in");
    });
  });
 

// const urlencodedParser = bodyParser.urlencoded({extended: false});

// app.get("/in", urlencodedParser, function (request, response) {
//     response.sendFile(__dirname+"\\index\\" + "in.html");
// });

// app.post("/in", urlencodedParser, function (request, response) {
//     if(!request.body) return response.sendStatus(400);
//     console.log(request.body);
//     if(request.body.userName=='Tom' && request.body.userAge=='26'){
    


        
//         response.send(`${request.body.userName} - ${request.body.userAge}`); 
    
    
    
//     }else{response.send("неверный логин или пароль");}
//     //response.send(`${request.body.userName} - ${request.body.userAge}`);
// });
  
// app.get("/", function(request, response){
//     response.send("Главная страница");
// });

app.listen(8082);