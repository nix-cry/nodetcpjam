// var cookieParser = require("cookie-parser");
// var session = require('express-session');
// var MSSQLStore = require("connect-mysql2")(session);
// var mysql = require("mysql2");

// module.export = {

//     createStore: function (){

//         var config = {
            
//               connectionLimit: 5,
//             host: "90.189.149.126",
//             user: "node",
//             password: "t8hoYFkD6TAO9V0v",
//             database: "node",

//         }
// return new MSSQLStore(config);
//     }

// }