
const MongoClient = require("mongodb").MongoClient;

const url = "mongodb://localhost:27017/";
const mongoClient = new MongoClient(url, { useUnifiedTopology: true });

const path  = require("path");
var fs = require('fs');
var app =require('express') (); 
//var siofu = require("socketio-file-upload");
var http =require('http').Server(app);
var io =require('socket.io')(http);
const bodyParser = require('body-parser');
const express = require('express');
const multer  = require("multer");
//const app = express();
var upload_f = multer({dest:"publish"});
app.use('/publish/', express.static('publish'));

const urlencodedParser = bodyParser.urlencoded({extended: false});
app.set('view engine', 'ejs');
//app.use(express.urlencoded({ extended: true }));
//app.use(express.json());



//app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname));


app.set('view engine', 'ejs');
app.get('/',(req,res) => {

    res.render('chat2');

});

app.post("/chat/", urlencodedParser, upload_f.any(), (req, res) => {
  let filedata = req.files;
  var str_nme = req.body.name;
  var str_msg = req.body.msg;
  var str_time = req.body.timestr;
  console.log('Подключился пользователь post');

console.log(filedata)
  let dist = [];
  for(let i = 0; i < filedata.length; i++){
      var img = filedata[i].mimetype;  
      var arr = img.split('/');
      //var type = mimetype.split('/');

      dist[i] = { "path" : "/publish/"+filedata[i].filename+"."+arr[1], "origname" : filedata[i].originalname, "type" : arr[0] };
      //filedata[i].originalname            
      fs.rename('publish/'+filedata[i].filename, 'publish/'+filedata[i].filename+'.'+arr[1], function(err) {
          if ( err ) console.log('ERROR: ' + err);
      });
      
  }
  console.log('Подключился пользователь post');
  console.log(dist);

            var config = {
            files : dist,
            name : str_nme,
            msg : str_msg,
            timestr : str_time,
            
            };
  
      // mongoClient.connect( function(err, client){
      //   const db = client.db("testchat"); 
      //   const collection = db.collection("users");
      
      //   if(err) return console.log(err);
            
      //   collection.find().toArray(function(err, results){
                     
      //     console.log(results);
      //         //console.log('Подключился пользователь: ' );
      //       socket.emit('chat message', results);     
            
      
      //       //client.close();
      //   });
      // });

        mongoClient.connect(function(err, client){
      
        

            const db1 = client.db("testchat");
            const collection = db1.collection("users");
            
            collection.insertOne(config, function(err, results){
              if(err){ 
                return console.log(err);
            }
                console.log(results);

                res.json( {

                  code: "01",
                  text: "Add",
                  data: results,
      
              });


                client.close();
            });
        });





});


app.use('/img/', express.static('img'));

io.on('connection',  function(socket) { 
  console.log('Подключился пользователь');

  mongoClient.connect( function(err, client){
    const db = client.db("testchat"); 
    const collection = db.collection("users");
  
    if(err) return console.log(err);
        
    collection.find().toArray(function(err, results){
                 
      console.log(results);
          //console.log('Подключился пользователь: ' );
        socket.emit('chat message', results);     
        
  
        //client.close();
    });
  });

  socket.on('disconnect', function() {
    console.log('Отключился пользователь');

  }); 





 
 socket.on('chat message', function(msg) { 

  //upload_f.any();


  
 
  io.emit('chat message', msg);  
  console.log('Пришло сообщение: ' + msg);
//   var uploader = new SocketIOFile(socket, {
//     // uploadDir: {			// multiple directories
//     // 	music: 'data/music',
//     // 	document: 'data/document'
//     // },
//     uploadDir: 'publish',							// simple directory
//     //accepts: ['audio/mpeg', 'audio/mp3'],		// chrome and some of browsers checking mp3 as 'audio/mp3', not 'audio/mpeg'
//     maxFileSize: 4194304, 						// 4 MB. default is undefined(no limit)
//     chunkSize: 10240,							// default is 10240(1KB)
//     transmissionDelay: 0,						// delay of each transmission, higher value saves more cpu resources, lower upload speed. default is 0(no delay)
//     overwrite: true 							// overwrite file if exists, default is true.
// });
// uploader.on('start', (fileInfo) => {
//   console.log('Start uploading');
//   console.log(fileInfo);
// });

  //let user =                msg ;

  //mongoClient.connect(function(err, client){
    //console.log('Пришло сообщение: ' + err);
    // const db1 = client.db("testchat");
    // const collection = db1.collection("users");
     
    // collection.insertOne(user, function(err, results){
    //   if(err){ 
    //     return console.log(err);
    // }
    //     console.log(results);
    //     client.close();
    // });
//});


     
});

}); 




//app.use('/', router);

http.listen(8082, function( ) { 
  console.log('Слушаем на *:8082');
});


// var WS = new require("ws");

// var ws = new WS.Server({
//        port: 8082
//    });

//    ws.on("connection", function(ws) {

//    console.log("New player connected.")
// });