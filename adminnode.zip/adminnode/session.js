
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');

const multer  = require("multer");
const path  = require("path");

const mysql = require("mysql2");
const pool = mysql.createPool({
      connectionLimit: 5,
    host: "90.189.149.126",
    user: "node",
    password: "t8hoYFkD6TAO9V0v",
    database: "node",
    
    
});

const prom = mysql.createPool({
      connectionLimit: 5,
    host: "90.189.149.126",
    user: "node",
    password: "t8hoYFkD6TAO9V0v",
    database: "node",
    
    
}).promise();

const router = express.Router();
const app = express();

app.use(session({secret: 'ssshhhhh',saveUninitialized: true,resave: true}));

app.use(bodyParser.json());      
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static(__dirname + '/views'));
app.set("view engine", "hbs");
app.set('view engine', 'ejs');
const urlencodedParser = bodyParser.urlencoded({extended: false});

var sess; // global session, NOT recommended
// var users_db = [
// { username: "admin", pswrd: "12345" }, 
// { username: "maneger1", pswrd: "maneger1" }, 
// { username: "maneger2", pswrd: "maneger2" }

// ];

// var users_db; 
// function makeRequest(){

// var querySelectUser = 'SELECT * FROM users';

// return pool.query(querySelectUser, function(error, results){

// 	      if (error) throw error;

// 	      //console.log(results);
// 	      //return results;

// 	      //console.log(res + ' - Это из функции');

// 	      //workWithResult(results);

	      

// 	  });

// 	}


//   const users_db = function( ){
//     return new Promise( async (resolve, reject)=> {
//         //const sql = "SELECT postID, postTitle, userID, img FROM post where address=? and userID!=? limit ?,?";
//         var users_db = pool.execute("SELECT * FROM users", [], function(err, data) {
//             if( !err ){
//                 resolve( data ) 
//             }else{
//                 resolve(false) 
//             }
//         });
//     })
// }

//function resultDb(result_data){ console.log(result_data);}
//var usDb = makeRequest();

//console.log("DB");
router.get('/admin/',(req,res) => {
    sess = req.session;
    if(sess.email) {
        return res.redirect('/admin/in');
    }
    res.render("admin.hbs");
    //res.sendFile('index.html');
});

router.post('/login',(req,res) => {
    sess = req.session;
    sess.email = req.body.email;
    sess.pass = req.body.pass;
    res.end('done');
});

//router.get('/admin',(req,res) => {
    let checkSignIn = function (req,res, next)  {
        sess = req.session;
    
         var UserYes;
         var querySelectUser = 'SELECT * FROM users';
         pool.execute(querySelectUser, function(error, results){

         for( var i = 0; i < results.length; i++)
         {
               var u = results[i];

               if(sess.email === u.name && sess.pass === u.pass)
               {
                    UserYes = "Yes";
                    var f = results[i];
               }
         }
         if(UserYes !== undefined ){
            req.avatar = f.avatar;
//=========================================================================
          //console.log(sess.pass + " " +UserYes + " "+ sess.email + " " + sess.pass);
        //   pool.query("SELECT * FROM primer", function(err, data) {
  
        //     if(err) return console.log(err);
            
        //     res.render("index.hbs", {
        //       session: req.session.showAd,
        //       title: "111",
        //         users: data,
        //     });
      
        //   });

        next();
        //app.use('/create/', express.static('publish'));

//=========================================================================

         }
         else
         {
              
            res.redirect('/logout');
         }
    
    });
        
};

router.get("/admin/in", checkSignIn, (req, res) => {

  
    pool.query("SELECT * FROM primer", function(err, data) {

      if(err) return console.log(err);
      
      res.render("index.ejs", {
            session: req.session.showAd,
            title: sess.email,
            users: data,
            avatar: req.avatar,
      });

    });

    router.get("/admin/create", function(req, res){
        res.render("create.hbs");
    });

    router.get("/admin/createuser", function(req, res){
        res.render("createusers.hbs");
    });

    app.get("/admin/edit/:id", function(req, res){
        const id = req.params.id;
        pool.query("SELECT * FROM primer WHERE id=?", [id], function(err, data) {
          if(err) return console.log(err);
           res.render("edit.hbs", {
              user: data[0]
          });
        });
      });



    app.post("/admin/delete/:id", function(req, res){
          
        const id = req.params.id;
        pool.query("DELETE FROM primer WHERE id=?", [id], function(err, data) {
          if(err) return console.log(err);
          res.redirect("/in");
        });
      });
      
});

app.use('/publish/', express.static('publish'));
app.use(express.static(__dirname));
var upload_f = multer({dest:"publish"});

app.post("/admin/create", urlencodedParser, upload_f.any(), function (req, res, next) {
         
    if(!req.body) return res.sendStatus(400);
    const name = req.body.name;
    const age = req.body.age;
    const fl = req.body.filedata;

   
    let filedata = req.files;
    console.log(filedata);
    if(!filedata){
        console.log("Ошибка при загрузке файла");
    }else{

        console.log("Файл загружен"+ filedata.length + filedata[0].filename);
       // console.log(filedata);
    }


        let dist = '';
        for(let i = 0; i < filedata.length; i++){
            dist += "/publish/"+filedata[i].filename; 
        }
        pool.query("INSERT INTO primer (id, pr_name, pr_name2, pr_name3 ) VALUES (?,?,?,?)", [name,dist,name, age], function(err, data) {
            if(err) return console.log(err);
             res.redirect("/admin/in");
    });

});

app.post("/admin/createuser", urlencodedParser, upload_f.any(), function (req, res, next) {
         
    if(!req.body) return res.sendStatus(400);
    const name = req.body.name;
    const pass = req.body.pass;
    //const fl = req.body.filedata;

   
    let filedata = req.files;
    // console.log(filedata);
    if(!filedata){
        console.log("Ошибка при загрузке файла");
    }else{

        console.log("Файл загружен"+filedata[0].filename);
       // console.log(filedata);
    }


        
        //for(let i = 0; i < filedata.length; i++){
            var dist = "/publish/"+filedata[0].filename; 
        //}
        pool.query("INSERT INTO users (id, name, pass, avatar ) VALUES (?,?,?,?)", [2,name,pass,dist], function(err, data) {
            if(err) return console.log(err);
             res.redirect("/admin/in");
    });

});

app.post("/admin/edit/", urlencodedParser, upload_f.any(), function (req, res) {
         
    if(!req.body) return res.sendStatus(400);
    //const name = req.body.name;
    const age = req.body.age;
    const id = req.body.name;
    const fl = req.body.filedata;

    let filedata = req.files;
    console.log(filedata);
    if(!filedata){
        console.log("Ошибка при загрузке файла");
    }else{
        console.log("Файл загружен");
       // console.log(filedata);
    }
    let dist = '';
    for(let i = 0; i < filedata.length; i++){
        dist += "/publish/"+filedata[i].filename; 
    }

    pool.query("UPDATE primer SET pr_name=?, pr_name2=?, pr_name3=? WHERE id=?", [dist, id, age, id], function(err, data) {
      if(err) return console.log(err);
       
      res.redirect("/admin/in");
    });
  });


  app.post("/admin/delete/:id", function(req, res){
          
    const id = req.params.id;
    pool.query("DELETE FROM primer WHERE id=?", [id], function(err, data) {
      if(err) return console.log(err);
      res.redirect("/admin/in");
    });
  });




router.get('/logout',(req,res) => {
    req.session.destroy((err) => {
        if(err) {
            return console.log(err);
        }
        res.redirect('/admin/');
    });

});

app.use('/', router);

app.get("/api", function(req, res){
    pool.query("SELECT * FROM primer", function(err, data) {
      if(err) return console.log(err);
    //   for(let i;i<data.length;i++){

    //   }
      
      res.json({
        elements: data
    });
  
    });
  });

app.listen(8082);