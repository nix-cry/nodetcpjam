
// const express = require('express');
// const session = require('express-session');
// var moment = require('moment');
// const multer  = require("multer");
// const path  = require("path");

// const router = express.Router();
// const app = express();


// const mysql = require("mysql2");
// const pool = mysql.createPool({
//       connectionLimit: 5,
//     host: "90.189.149.126",
//     user: "node",
//     password: "t8hoYFkD6TAO9V0v",
//     database: "nodenew",
     
// });

// const prom = mysql.createPool({
//       connectionLimit: 5,
//     host: "90.189.149.126",
//     user: "node",
//     password: "t8hoYFkD6TAO9V0v",
//     database: "nodenew",
       
// }).promise();


// app.use(express.urlencoded({ extended: true }));
// app.use(express.json());

// app.use('/publish/', express.static('publish'));



// app.use(express.static(__dirname));
// var upload_f = multer({dest:"publish"});

// app.use(session({secret: 'ssshhhhh',saveUninitialized: true,resave: true}));
// var sess;

// router.get('/log/',(req,res) => {
//     sess = req.session;
//     if(sess.log && sess.pass) {
//         res.redirect('/admin/');

//     }else{
//         res.redirect('/log');
//     }
//     //res.sendFile('index.html');
// });

// router.post('/log',(req,res) => {
//     sess = req.session;
//     sess.email = req.body.email;
//     sess.pass = req.body.pass;
//     res.end('done');
// });

// let checkSignIn = function (req,res, next)  {
//     sess = req.session;

//      var UserYes;
//      var querySelectUser = 'SELECT * FROM users';
//      pool.execute(querySelectUser, function(error, results){

//      for( var i = 0; i < results.length; i++)
//      {
//            var u = results[i];

//            if(sess.email === u.name && sess.pass === u.pass)
//            {
//                 UserYes = "Yes";
//                 var f = results[i];
//            }
//      }
//      if(UserYes !== undefined ){
//         req.avatar = f.avatar;
// //=========================================================================
//       //console.log(sess.pass + " " +UserYes + " "+ sess.email + " " + sess.pass);
//     //   pool.query("SELECT * FROM primer", function(err, data) {

//     //     if(err) return console.log(err);
        
//     //     res.render("index.hbs", {
//     //       session: req.session.showAd,
//     //       title: "111",
//     //         users: data,
//     //     });
  
//     //   });

//     next();
//     //app.use('/create/', express.static('publish'));

// //=========================================================================

//      }
//      else
//      {
          
//         res.redirect('/log');
//      }

// });
    
// };



// router.all("/admin/", checkSignIn, (req, res) => {

//     console.log('In');
  
//     //res.redirect('/log');
//       // pool.query("SELECT * FROM primer", function(err, data) {
  
//       //   if(err) return console.log(err);
        
//       //   res.render("index.ejs", {
//       //         session: req.session.showAd,
//       //         title: sess.email,
//       //         users: data,
//       //         avatar: req.avatar,
//       //   });
  
//       // });
  
//       // router.get("/admin/create", function(req, res){
//       //     res.render("create.hbs");
//       // });
  
//       // router.get("/admin/createuser", function(req, res){
//       //     res.render("createusers.hbs");
//       // });
  
//       // app.get("/admin/edit/:id", function(req, res){
//       //     const id = req.params.id;
//       //     pool.query("SELECT * FROM primer WHERE id=?", [id], function(err, data) {
//       //       if(err) return console.log(err);
//       //        res.render("edit.hbs", {
//       //           user: data[0]
//       //       });
//       //     });
//       //   });
  
  
  
//       // app.post("/admin/delete/:id", function(req, res){
            
//       //     const id = req.params.id;
//       //     pool.query("DELETE FROM primer WHERE id=?", [id], function(err, data) {
//       //       if(err) return console.log(err);
//       //       res.redirect("/in");
//       //     });
//       //   });
        
//   });



//   app.use('/admin/',express.static(path.join(__dirname, 'admin/')));




// router.post("/cmsfile/", upload_f.any(), (req, res) => {
//     //var userName = req.body.text;
//     //var userAge = req.body.age;
//     let filedata = req.files;
//     let Textt = req.body.someField;
//     //console.log(userName);
//     console.log(filedata);
//     if(!filedata){
//         console.log("Ошибка при загрузке файла");
//     }else{

//         console.log(Textt);
//         console.log("Файл загружен"+ filedata.length + filedata[0].filename);
      
//     }

//     pool.query("SELECT * FROM user", function(err, data) {

//         if(err) return console.log(err);
//         res.json(data);
//         console.log(data);
//         //console.log(userName);
//     });      
// });

// // router.get("/cmsdata/", (req, res) => {

// //     var userName = req.query;
// //     var now = moment();

// //     console.log("Fff"+userName.text+" "+ userName.key+" :: "+now.format('YYYY-MM-DDTh:mm:ss'));

// //     pool.query("SELECT * FROM user", function(err, data) {

// //         if(err) return console.log(err);
// //         res.json(data);
// //         //console.log(data);
// //         //if()
// //         var u = data[0];
// //         console.log(u.time_user);

// //         var d0 = new Date(u.time_user);
// //         console.log(d0.getUTCHours());
// //         console.log(d0.getUTCMinutes());
// //         var d1 = new Date(now.format('YYYY-MM-DD h:mm:ss'));
// //         console.log(d1.getHours());
// //         console.log(d1.getMinutes());
// //         //console.log(userName);

// //             // pool.query("INSERT INTO primer (id, pr_name, pr_name2, pr_name3 ) VALUES (?,?,?,?)", [name,dist,name, age], function(err, data) {
// //             //     if(err) return console.log(err);
// //             //         //res.redirect("/admin/in");
// //             // });

// //     });   
    
    
// // });


// // router.get("/cmsin/", (req, res) => {

// //     var userName = req.query;
// //     var now = moment();

// //     console.log("Fff"+userName.text+" "+ userName.key+" :: "+now.format('YYYY-MM-DDTh:mm:ss'));

// //     pool.query("SELECT * FROM user", function(err, data) {

// //         if(err) return console.log(err);
// //         res.json(data);
// //         //console.log(data);
// //         //if()
// //         var u = data[0];
// //         console.log(u.time_user);

// //         var d0 = new Date(u.time_user);
// //         console.log(d0.getUTCHours());
// //         console.log(d0.getUTCMinutes());
// //         var d1 = new Date(now.format('YYYY-MM-DD h:mm:ss'));
// //         console.log(d1.getHours());
// //         console.log(d1.getMinutes());
// //         //console.log(userName);

// //             // pool.query("INSERT INTO primer (id_user, name_user, img_user, time_user, id_glob, id_key, save_user  ) VALUES (?,?,?,?)", [name,dist,name, age], function(err, data) {
// //             //     if(err) return console.log(err);
// //             //         //res.redirect("/admin/in");
// //             // });
// //         //if(){}
// //             // pool.query("UPDATE user SET name_user=?, img_user=?, time_user=?, id_glob=?, id_key=?, save_user=? WHERE id_user=?", [dist, id, age, id], function(err, data) {
// //             //     if(err) return console.log(err);
// //             //     res.json(data);
// //             //     // res.redirect("/admin/in");
// //             //   });

// //     });   
    
    
// // });

// router.get('/log/',(req,res) => {
//     req.session.destroy((err) => {
//         if(err) {
//             return console.log(err);
//         }
//         res.redirect('/admin/');
//     });

// });

// app.use('/', router);


// app.listen(8082);













//////////=================================NEW









const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
var MySQLStore = require('express-mysql-session')(session);

const multer  = require("multer");
const path  = require("path");
var fs = require('fs');
const mysql = require("mysql2");
const pool = mysql.createPool({
      connectionLimit: 5,
    host: "localhost",
    user: "root",
    password: "root",
    database: "tstndjs_2",
    
    
});

const prom = mysql.createPool({
      connectionLimit: 5,
    host: "localhost",
    user: "root",
    password: "root",
    database: "tstndjs_2",
    
    
}).promise();

const router = express.Router();
const app = express();
const crypto = require('crypto');
//app.use(session({secret: 'ssshhhhh',saveUninitialized: true,resave: true}));

var options = {
	host: "localhost",
	port: 3306,
    user: "root",
    password: "root",
    database: "tstndjs_2",
    schema: {
		tableName: 'custom_sessions_table_name',
		columnNames: {
			session_id: 'custom_session_id',
			expires: 'custom_expires_column_name',
			data: 'custom_data_column_name'
        }
    }
};

var sessionStore = new MySQLStore(options);

app.use(session({
	key: 'session_cookie_name',
	secret: 'session_cookie_secret',
	store: sessionStore,
	resave: false,
	saveUninitialized: false
}));

app.use(bodyParser.json());      
app.use(bodyParser.urlencoded({extended: true}));


app.set("view engine", "hbs");
app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use('/publish/', express.static('publish'));



app.use(express.static(__dirname));
var upload_f = multer({dest:"publish"});

const urlencodedParser = bodyParser.urlencoded({extended: false});

let sess; // global session, NOT recommended
// var users_db = [
// { username: "admin", pswrd: "12345" }, 
// { username: "maneger1", pswrd: "maneger1" }, 
// { username: "maneger2", pswrd: "maneger2" }

// ];

// var users_db; 
// function makeRequest(){

// var querySelectUser = 'SELECT * FROM users';

// return pool.query(querySelectUser, function(error, results){

// 	      if (error) throw error;

// 	      //console.log(results);
// 	      //return results;

// 	      //console.log(res + ' - Это из функции');

// 	      //workWithResult(results);

	      

// 	  });

// 	}


//   const users_db = function( ){
//     return new Promise( async (resolve, reject)=> {
//         //const sql = "SELECT postID, postTitle, userID, img FROM post where address=? and userID!=? limit ?,?";
//         var users_db = pool.execute("SELECT * FROM users", [], function(err, data) {
//             if( !err ){
//                 resolve( data ) 
//             }else{
//                 resolve(false) 
//             }
//         });
//     })
// }

//function resultDb(result_data){ console.log(result_data);}
//var usDb = makeRequest();

//console.log("DB");
// router.get('/admin/',(req,res) => {
//     sess = req.session;
//     if(sess.email) {
//         return res.redirect('/admin/in');
//     }
//     res.redirect("/log/");
//     //res.sendFile('index.html');
// });



//router.get('/admin',(req,res) => {


    //const urlencodedParser = bodyParser.urlencoded({extended: false});

router.get('/log',  (req,res) => {

    res.render("log");
});

app.post('/log', urlencodedParser, upload_f.any(), (req,res) => {
    
    emailStart = req.body.email;
    passStart = req.body.password;
    var mass;
    //console.log(req.body.someEmail+' '+req.body.somePass);
    //var adminNameData = crypto.createHash('md5').update(emailStart).digest("hex");
    var passStartData = crypto.createHash('md5').update(passStart).digest("hex");
    var UserYes;
    var querySelectUser = 'SELECT `id` FROM `users` WHERE `username`="'+emailStart+'" AND `pass`="'+passStartData+'"';
    pool.execute(querySelectUser, function(error, results){
        //results;
        mass = results;
        console.log(error);
        //console.log(results[0].id);
    // for( var i = 0; i < results.length; i++)
    // {
    //       var u = results[i];
    //       console.log(u.name+' '+emailStart);
    //       if(emailStart === u.name && passStartData === u.pass)
    //       {
    //            UserYes = "Yes";
    //            var f = results[i];
    //            console.log(UserYes);
    //       }
    // }
    if(results[0].id != undefined ){

        req.id = results[0].id;
        sess = req.session;
        Sid = req.session.id;
        sess.email = emailStart;
        sess.pass = passStartData;
        console.log(Sid);

        res.redirect('/admin');
    }
    else
    {
        res.json({
            done: "note"
        });

    }
    });
});



let checkSignIn = function (req,res, next)  {
        sess = req.session;
        var querySelectUser = 'SELECT * FROM `users` WHERE `username`="'+sess.email+'" AND `pass`="'+sess.pass+'"';
        pool.execute(querySelectUser, function(error, results){
            //console.log(results[0]);
            if(results[0] !== undefined ){
                req.users = results;
                //console.log(results[0]);
                next();
            }
            else
            {
                res.redirect('/logout');
            }
        });
};



router.get("/admin/", checkSignIn, upload_f.any(), (req, res) => {
    console.log(req.users[0].id);
    var querySelectUser = 'SELECT `users`.*, `usersdata`.* FROM `users` LEFT JOIN `usersdata` ON `users`.`id` = `usersdata`.`id_user` WHERE `users`.`id` ='+req.users[0].id;
    pool.execute(querySelectUser, function(error, results){ 
        //req.users
        //console.log("Vvv");
        //console.log("Results: "+results);
        
        var querySelectUser = 'SELECT `users`.*, `usersdata`.* FROM `users` LEFT JOIN `usersdata` ON `users`.`id` = `usersdata`.`id_user`';
        pool.execute(querySelectUser, function(error, results2){ 
            var querySelectUser = 'SELECT `element`.*, `content`.* FROM `element` LEFT JOIN `content` ON `content`.`id_element` = `element`.`id` ';
            pool.execute(querySelectUser, function(error, results3){

                console.log("Results: "+results3[0].id_element);
                
                //var tmp = new Array();
                var dtc = results3.length;
                //$dtc1 = $dtc;
                  
                  for( var i = 0; i < dtc; i++) // i - номер текущего шага
                  { 
                    var pos = i; 
                    tmp = results3[i];
                    
                    for(var j = i + 1; j < dtc; j++) // цикл выбора наименьшего элемента
                    {
              
                        //strtotime($date1)< strtotime($tmp)
                      if ( results3[j].id > tmp.id ) 
                      {
                        pos = j; 
                        tmp = results3[j]; 
                      }
                    
                    }
                    
                    results3[pos] = results3[i]; 
                    results3[i] = tmp; // меняем местами наименьший с a[i]
                  
                  }



                res.render("admin.ejs", {
                    sess: req.session.id,
                    user: results,
                    users: results2,
                    elements: results3
                });

            });

        });


    });



//====================================================Users in admin=========================================================Start

//==========================================================================================================================Delete

router.get("/admingetdelete/", (req, res) => {
    var n = req.query.id;
console.log("D"+n);
//DELETE FROM `users` WHERE 0
    var querySelectUser = 'DELETE FROM `users` WHERE `id` ='+n;
    pool.execute(querySelectUser, function(error, results){ 
        //req.users
        console.log(results);
        //req.res = results;
        res.json({
            done: "delete id"+n,
            
        });
    });


    
});




//////////==================================================================================================================Update

router.post("/adminpostupdate/", urlencodedParser, upload_f.any(),(req, res) => {
    var popup2IdEdit = req.body.popup2IdEdit;
    var popup2LoginEdit = req.body.popup2LoginEdit;
    var popup2NameEdit = req.body.popup2NameEdit;
    var popup2MiddlenameEdit = req.body.popup2MiddlenameEdit;
    var popup2LastnameEdit = req.body.popup2LastnameEdit;
    var popup2PhoneEdit = req.body.popup2PhoneEdit;
    var popup2MailEdit = req.body.popup2MailEdit;
    var popup2ImgEdit = req.body.popup2ImgEdit;

    //formdata.append('popup2ImgEdit', img_user);

    let filedata = req.files;

    
    console.log(filedata);

    let dist = '';
    for(let i = 0; i < filedata.length; i++){
        var img = filedata[i].mimetype;  
        var arr = img.split('/');

        dist += "/publish/"+filedata[i].filename+"."+arr[1];
        //filedata[i].originalname            
        fs.rename('publish\\'+filedata[i].filename, 'publish\\'+filedata[i].filename+'.'+arr[1], function(err) {
            if ( err ) console.log('ERROR: ' + err);
        });

    }

    if(popup2ImgEdit=='')
    {
        fileimg = dist;
    }
    else 
    {
        fileimg = popup2ImgEdit;
    }
    console.log(filedata);

        //UPDATE usersdata SET name=?, middlemame=?, lastname=?, phone=?, mail=?, img=?, active=?, sort=? WHERE id_user=?
     pool.query("UPDATE usersdata SET name=?, middlemame=?, lastname=?, phone=?, mail=?, img=?, active=?, sort=? WHERE id_user=?", [popup2NameEdit,popup2MiddlenameEdit,popup2LastnameEdit,popup2PhoneEdit,popup2MailEdit,fileimg,1,1,popup2IdEdit], function(err, data) {
         if(err) return console.log(err);
         res.json({
            text: "", 
            done: "Yes",

            
        });
     });
  
    });

router.get("/adminget/", (req, res) => {
    var n = req.query.id;
console.log("D"+n);

    var querySelectUser = 'SELECT `users`.*, `usersdata`.* FROM `users` LEFT JOIN `usersdata` ON `users`.`id` = `usersdata`.`id_user` WHERE `users`.`id` ='+n;
    pool.execute(querySelectUser, function(error, results){ 
        //req.users
        console.log(results);
        req.res = results;
        res.json({
            done: req.res,
            
        });
    });


    
});


//////////==================================================================================================================Add

router.post("/adminpostadd/", urlencodedParser, upload_f.any(),(req, res) => {
    var popup2IdEdit = req.body.popup2IdEdit;
    var popup2LoginEdit = req.body.popup2LoginEdit;
    var popup2NameEdit = req.body.popup2NameEdit;
    var popup2MiddlenameEdit = req.body.popup2MiddlenameEdit;
    var popup2LastnameEdit = req.body.popup2LastnameEdit;
    var popup2PhoneEdit = req.body.popup2PhoneEdit;
    var popup2MailEdit = req.body.popup2MailEdit;
    let filedata = req.files;

    


    let dist = '';
        for(let i = 0; i < filedata.length; i++){
            dist += "/publish/"+filedata[i].filename; 
        }

        //UPDATE usersdata SET name=?, middlemame=?, lastname=?, phone=?, mail=?, img=?, active=?, sort=? WHERE id_user=?
     pool.query("UPDATE usersdata SET name=?, middlemame=?, lastname=?, phone=?, mail=?, img=?, active=?, sort=? WHERE id_user=?", [popup2NameEdit,popup2MiddlenameEdit,popup2LastnameEdit,popup2PhoneEdit,popup2MailEdit,dist,1,1,popup2IdEdit], function(err, data) {
         if(err) return console.log(err);
         res.json({
            done: "Yes",
            
        });
     });
  
    });

router.get("/adminget/", (req, res) => {
    var n = req.query.id;
console.log("D"+n);

    var querySelectUser = 'SELECT `users`.*, `usersdata`.* FROM `users` LEFT JOIN `usersdata` ON `users`.`id` = `usersdata`.`id_user` WHERE `users`.`id` ='+n;
    pool.execute(querySelectUser, function(error, results){ 
        //req.users
        console.log(results);
        req.res = results;
        res.json({
            done: req.res,
            
        });
    });


    
});

//================================================================================================================================AddAdmin

router.get('/addusersigninadmin',(req,res) => {

    var user = req.query.name;
    var pass = req.query.pass;
    var symbol = false;
    var user_dw = user.toLowerCase();
    let arr_str = user_dw.split('');
    let arr_en = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z','0','1','2','3','4','5','6','7','8','9'];

    for(var arrt1=0; arrt1<=arr_str.length-1;arrt1++){
        if(arr_en.indexOf( arr_str[arrt1] ) == -1){
            symbol=true;
        }
    }

    if(symbol==true){
        res.json( {

            codeError: "01",
            textError: "Invalid login"

        });
    }
    else
    {
        var passData = crypto.createHash('md5').update(pass).digest("hex");
        //console.log(adminPassData);

        var querySelectUser = 'SELECT * FROM `users` WHERE `username`="'+user+'" ';
        pool.execute(querySelectUser, function(error, results){

            //var yratext=/['0-9',':']/;

            // user.toLowerCase();
            // pass.toLowerCase();
            if(results[0] !== undefined ){
                //res.send("Such a user exists");
                res.json( {

                    codeError: "0",
                    textError: "Such a user exists "

                });
            }
            else
            {

                pool.query("INSERT INTO users (username, pass ) VALUES (?,?)", [user,passData], function(err, data) {
                    if(err) return console.log(err);

                
                    var querySelectUser = 'SELECT `id` FROM `users` WHERE `username`="'+user+'" AND `pass`="'+passData+'"';
                    pool.execute(querySelectUser, function(error, results){
                    
                        pool.query("INSERT INTO usersdata (id_user ) VALUES (?)", [results[0].id], function(err, data) {

                            res.json( {

                                code: "1",
                                text: "User added"

                            });
                        
                        });
                    
                    
                    });
                
                });
            }


        });
    }


});

//=================================

//======================================================Users in admin============================================================================And

//=================================================Element in admin==================================================================Start

//======================================================================================================================================Add
router.post("/adminelementaddpost/", urlencodedParser, upload_f.any(),(req, res) => {
    var popup1Name = req.body.popup1Name;
    var popup1Date = req.body.popup1Date;
    var popup1Text1 = req.body.popup1Text1;
    var popup1Text2 = req.body.popup1Text2;
    var popup1Date1 = req.body.popup1Date1;
    var popup1Date2 = req.body.popup1Date2;
    var popup1Date2 = req.body.popup1Date2;



    let filedata = req.files;
    console.log(filedata);
    let dist = '';
    let format = '';


        for(let i = 0; i < filedata.length; i++){
            var img = filedata[i].mimetype;  
            var arr = img.split('/');

            dist += "/publish/"+filedata[i].filename+"."+arr[1]+";";
            //filedata[i].originalname            
            fs.rename('publish\\'+filedata[i].filename, 'publish\\'+filedata[i].filename+'.'+arr[1], function(err) {
                if ( err ) console.log('ERROR: ' + err);
            });
            
        }

console.log(dist);
        //UPDATE usersdata SET name=?, middlemame=?, lastname=?, phone=?, mail=?, img=?, active=?, sort=? WHERE id_user=?
        //INSERT INTO usersdata (id_user ) VALUES (?)
    //pool.query("UPDATE usersdata SET name=?, middlemame=?, lastname=?, phone=?, mail=?, img=?, active=?, sort=? WHERE id_user=?", [popup2NameEdit,popup2MiddlenameEdit,popup2LastnameEdit,popup2PhoneEdit,popup2MailEdit,dist,1,1,popup2IdEdit], function(err, data) {
        console.log(popup1Date);
    pool.query("INSERT INTO element (name,datetime) VALUES (?,?)", [popup1Name,popup1Date], function(err, data) {
        console.log(popup1Date);
        var querySelectUser = 'SELECT `id` FROM `element` where `id` in (SELECT MAX(id) FROM `element`)';
        pool.execute(querySelectUser, function(error, results){

            console.log(results[0].id,popup1Text1,popup1Text2,popup1Date1,popup1Date2);

            //INSERT INTO `content` (`id`, `id_element`, `text1`, `text2`, `mediaimg`, `mediavideo`, `datetimeStart`, `datetimeFinish`, `sort`, `ative`) VALUES ('1', '20', '1', '1', '1', '1', '2021-02-27 17:30:27', '2021-02-27 17:30:27', '500', '1');

            pool.query("INSERT INTO content (`id_element`, `text1`, `text2`, `mediaimg`, `mediavideo`, `datetimeStart`, `datetimeFinish`, `sort`, `active`) VALUES ("+results[0].id+", '"+popup1Text1+"', '"+popup1Text2+"', '"+dist+"', '1', '"+popup1Date1+"', '"+popup1Date2+"', '500', '1')", function(err1, data1) {
                if ( err ) console.log('ERROR: ' + err);
                console.log("Fff");

                res.json({
                    done: "Yes",
                    
                });
            });
        });
     });
  
    });

//=========================================================================================Update====================================================================================


router.post("/adminelementupdate/", urlencodedParser, upload_f.any(),(req, res) => {
    var popup1id = req.body.popup1id;
    var popup1NameElem = req.body.popup1NameElem;
    var popup1DateElemL = req.body.popup1DateElemL;
    var popup1Text1Elem = req.body.popup1Text1Elem;
    var popup1Text2Elem = req.body.popup1Text2Elem;
    var popup1Date1Elem = req.body.popup1Date1Elem;
    var popup1Date2Elem = req.body.popup1Date2Elem;
    var popup1ActiveElem = req.body.popup1ActiveElem;
    var popup1SortElem = req.body.popup1SortElem;
    
   console.log("Update"+ popup1id+' '+popup1ActiveElem+' '+popup1SortElem);
   var popup1StrFileImgOld = req.body.popup1StrFileImgOld;
    let filedata = req.files;

    let dist = '';
    for(let i = 0; i < filedata.length; i++){
        var img = filedata[i].mimetype;  
        var arr = img.split('/');

        dist += "/publish/"+filedata[i].filename+"."+arr[1]+";";
        //filedata[i].originalname            
        fs.rename('publish\\'+filedata[i].filename, 'publish\\'+filedata[i].filename+'.'+arr[1], function(err) {
            if ( err ) console.log('ERROR: ' + err);
        });
        
    }
    var mediaimg = dist+popup1StrFileImgOld;
        //UPDATE usersdata SET name=?, middlemame=?, lastname=?, phone=?, mail=?, img=?, active=?, sort=? WHERE id_user=?
     pool.query("UPDATE element SET name=?, datetime=?, sort=?, active=? WHERE id=?", [popup1NameElem,popup1DateElemL,popup1SortElem,popup1ActiveElem,popup1id], function(err, data) {
        //  if(err) return console.log(err);
        //  res.json({
        //     done: "Yes",
            
        // });
        pool.query("UPDATE content SET text1=?, text2=?, mediaimg=?, datetimeStart=?, datetimeFinish=?, sort=?, active=? WHERE id_element=?", [popup1Text1Elem,popup1Text2Elem,mediaimg,popup1Date1Elem,popup1Date2Elem,popup1SortElem,popup1ActiveElem,popup1id], function(err, data) {
             if(err) return console.log(err);
             res.json({
                done: "Yes",
                
            });
         });
     });
  
    });


//=============================================================================================================================================Get

router.get("/getelementadmin/", (req, res) => {
    var n = req.query.id;
    //var pass = req.query.pass;
console.log()
    var querySelectUser = 'SELECT `element`.*, `content`.* FROM `element` LEFT JOIN `content` ON `element`.`id` = `content`.`id_element` WHERE `element`.`id` ='+n;
                pool.execute(querySelectUser, function(error, results3){
    
                    console.log("Vvv");
                    console.log(results3);
    
                    res.json( {
     
                        elements: results3
                    });
    
                });
    
    
        
    });

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

router.get("/delelementadmin/", (req, res) => {

    var n = req.query.id;
console.log("D"+n);
//DELETE FROM `users` WHERE 0
    var querySelectUser = 'DELETE FROM `element` WHERE `id` ='+n;
    pool.execute(querySelectUser, function(error, results){ 
        //req.users
        console.log(results);
        //req.res = results;
        res.json({
            done: "delete id"+n,
            
        });
    });

    
    
        
    });

//=====================================================Element in admin============================================================================And
   

});



//Для внешнего запроса========================================================================================================================================
router.get("/getelementcontent/", (req, res) => {


var querySelectUser = 'SELECT `element`.*, `content`.* FROM `content` LEFT JOIN `element` ON `content`.`id_element` = `element`.`id` ';
            pool.execute(querySelectUser, function(error, results3){

                console.log("Vvv");
                console.log(results3[0]);

                res.json( {
 
                    elements: results3
                });

            });


    
});


// pool.query("SELECT * FROM primer", function(err, data) {

//   if(err) return console.log(err);
  
//   res.render("index.ejs", {
//         session: req.session.showAd,
//         title: sess.email,
//         users: data,
//         avatar: req.avatar,
//   });

// });

// router.get("/admin/create", function(req, res){
//     res.render("create.hbs");
// });

// router.get("/admin/createuser", function(req, res){
//     res.render("createusers.hbs");
// });

// app.get("/admin/edit/:id", function(req, res){
//     const id = req.params.id;
//     pool.query("SELECT * FROM primer WHERE id=?", [id], function(err, data) {
//       if(err) return console.log(err);
//        res.render("edit.hbs", {
//           user: data[0]
//       });
//     });
//   });



// app.post("/admin/delete/:id", function(req, res){
      
//     const id = req.params.id;
//     pool.query("DELETE FROM primer WHERE id=?", [id], function(err, data) {
//       if(err) return console.log(err);
//       res.redirect("/in");
//     });
//   });
  


// router.get('/logout',(req,res) => {
//     req.session.destroy((err) => {
//         if(err) {
//             return console.log(err);
//         }
//         res.redirect('/log/');
//     });

// });


router.get('/getusersigninadmin',(req,res) => {

    var user = req.query.name;
    var pass = req.query.pass;
    var symbol = false;
    var user_dw = user.toLowerCase();
    let arr_str = user_dw.split('');
    let arr_en = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z','0','1','2','3','4','5','6','7','8','9'];

    for(var arrt1=0; arrt1<=arr_str.length-1;arrt1++){
        if(arr_en.indexOf( arr_str[arrt1] ) == -1){
            symbol=true;
        }
    }

    if(symbol==true){
        res.json( {

            codeError: "01",
            textError: "Invalid login"

        });
    }
    else
    {
        var passData = crypto.createHash('md5').update(pass).digest("hex");
        //console.log(adminPassData);

        var querySelectUser = 'SELECT * FROM `users` WHERE `username`="'+user+'" ';
        pool.execute(querySelectUser, function(error, results){

            //var yratext=/['0-9',':']/;

            // user.toLowerCase();
            // pass.toLowerCase();
            if(results[0] !== undefined ){
                //res.send("Such a user exists");
                res.json( {

                    codeError: "0",
                    textError: "Such a user exists "

                });
            }
            else
            {

                pool.query("INSERT INTO users (username, pass ) VALUES (?,?)", [user,passData], function(err, data) {
                    if(err) return console.log(err);

                
                    var querySelectUser = 'SELECT `id` FROM `users` WHERE `username`="'+user+'" AND `pass`="'+passData+'"';
                    pool.execute(querySelectUser, function(error, results){
                    
                        pool.query("INSERT INTO usersdata (id_user ) VALUES (?)", [results[0].id], function(err, data) {

                            res.json( {

                                code: "1",
                                text: "User added"

                            });
                        
                        });
                    
                    
                    });
                
                });
            }


        });
    }


});


router.get('/logout',(req,res) => {
    req.session.destroy((err) => {
        if(err) {
            return console.log(err);
        }
        res.redirect('/log/');
    });

});

app.use('/', router);

// app.get("/api", function(req, res){
//     pool.query("SELECT * FROM primer", function(err, data) {
//       if(err) return console.log(err);
//     //   for(let i;i<data.length;i++){

//     //   }
      
//       res.json({
//         elements: data
//     });
  
//     });
//   });

app.listen(80);
// app.use('/publish/', express.static('publish'));
// app.use(express.static(__dirname));
// var upload_f = multer({dest:"publish"});

// app.post("/admin/create", urlencodedParser, upload_f.any(), function (req, res, next) {
         
//     if(!req.body) return res.sendStatus(400);
//     const name = req.body.name;
//     const age = req.body.age;
//     const fl = req.body.filedata;

   
//     let filedata = req.files;
//     console.log(filedata);
//     if(!filedata){
//         console.log("Ошибка при загрузке файла");
//     }else{

//         console.log("Файл загружен"+ filedata.length + filedata[0].filename);
//        // console.log(filedata);
//     }


//         let dist = '';
//         for(let i = 0; i < filedata.length; i++){
//             dist += "/publish/"+filedata[i].filename; 
//         }
//         pool.query("INSERT INTO primer (id, pr_name, pr_name2, pr_name3 ) VALUES (?,?,?,?)", [name,dist,name, age], function(err, data) {
//             if(err) return console.log(err);
//              res.redirect("/admin/in");
//     });

// });

// app.post("/admin/createuser", urlencodedParser, upload_f.any(), function (req, res, next) {
         
//     if(!req.body) return res.sendStatus(400);
//     const name = req.body.name;
//     const pass = req.body.pass;
//     //const fl = req.body.filedata;

   
//     let filedata = req.files;
//     // console.log(filedata);
//     if(!filedata){
//         console.log("Ошибка при загрузке файла");
//     }else{

//         console.log("Файл загружен"+filedata[0].filename);
//        // console.log(filedata);
//     }


        
//         //for(let i = 0; i < filedata.length; i++){
//             var dist = "/publish/"+filedata[0].filename; 
//         //}
//         pool.query("INSERT INTO users (id, name, pass, avatar ) VALUES (?,?,?,?)", [2,name,pass,dist], function(err, data) {
//             if(err) return console.log(err);
//              res.redirect("/admin/in");
//     });

// });

// app.post("/admin/edit/", urlencodedParser, upload_f.any(), function (req, res) {
         
//     if(!req.body) return res.sendStatus(400);
//     //const name = req.body.name;
//     const age = req.body.age;
//     const id = req.body.name;
//     const fl = req.body.filedata;

//     let filedata = req.files;
//     console.log(filedata);
//     if(!filedata){
//         console.log("Ошибка при загрузке файла");
//     }else{
//         console.log("Файл загружен");
//        // console.log(filedata);
//     }
//     let dist = '';
//     for(let i = 0; i < filedata.length; i++){
//         dist += "/publish/"+filedata[i].filename; 
//     }

//     pool.query("UPDATE primer SET pr_name=?, pr_name2=?, pr_name3=? WHERE id=?", [dist, id, age, id], function(err, data) {
//       if(err) return console.log(err);
       
//       res.redirect("/admin/in");
//     });
//   });


//   app.post("/admin/delete/:id", function(req, res){
          
//     const id = req.params.id;
//     pool.query("DELETE FROM primer WHERE id=?", [id], function(err, data) {
//       if(err) return console.log(err);
//       res.redirect("/admin/in");
//     });
//   });




